package org.grails.plugin.resource

import org.apache.commons.logging.LogFactory

/**
 *
 * Create bundle if doesn't exist
 * Append self to bundle if does exist
 * Change processed file to point at bundle
 * Make sure resources does not apply zip etc multiple times to the bundled file
 * Clear the bundle file at startup (how?)
 *
 * Perhaps just incorporate into resources core for now, during first copy and before applying mappers?
 */
class ResourceBundler {
    
    static log = LogFactory.getLog('org.grails.plugin.resource.ResourceBundler')

    static BUNDLE_DIR = "bundles"
    /**
     * Find all url() and fix up the url if it is not absolute
     * NOTE: This needs to run after any plugins that move resources around, but before any that obliterate
     * the content i.e. before minify or gzip
     */
    static mapper = { resource, resourceService ->
        /*
        def bundleId = resource.bundle
        if (bundleId) {
            def f = new File(resourceService.workDir, BUNDLE_DIR)
            f.mkdirs()
            def bundleFile = new File(f, bundleId)
            if (!bundleFile.exists()) {
                resource.attributes._bundleOwner = true
            }
            bundleFile << resource.processedFile.text
            resource.processedFile = bundleFile
            resource.actualUrl = "/${BUNDLE_DIR}/${bundleId}"
        }
        */
    }
}
