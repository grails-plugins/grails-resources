package org.grails.plugin.resource

class ResourcesFilters {

    def filters = {
        /*
        def u = resourceService.staticUrlPrefix + '/**'
        
        System.out.println "Loading filter! $u"
        staticResources(uri:u) {
            System.out.println "Eval filter"
            before = {
                System.out.println "In filter"
                if (log.debugEnabled) {
                    log.debug "Filter handling static content for ${request.requestURI}"
                }
                resourceService.processResource(request, response)
                return false // we've done it
            }
        }
        */
    }
    
}
