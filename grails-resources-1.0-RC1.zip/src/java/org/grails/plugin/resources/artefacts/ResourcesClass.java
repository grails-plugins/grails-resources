package org.grails.plugin.resources.artefacts;

import org.codehaus.groovy.grails.commons.GrailsClass;

public interface ResourcesClass extends GrailsClass {}