import org.codehaus.groovy.grails.plugins.codecs.SHA256Codec

def RESOURCE_PATTERNS = [
    "**/*.css",
    "**/*.js",
    "**/*.jpg",
    "**/*.png",
    "**/*.gif", 
    "**/*.jpeg"
]
/*
eventPackageAppEnd = { 

    println "Preparing resources..."
    
    def base = "${basedir}/web-app"
    def baseFile = new File(base)
    def resDir = "${basedir}/cached-resources"
    ant.mkdir(dir:resDir)
    
    def files = ant.fileScanner {
        RESOURCE_PATTERNS.each { p ->
            fileset(dir:base, includes:p)
        }
    }

    def fileMappings = [:]
    
    // Iterate over all qualifying files (css, js and png,gif,jpg)
    // Hash every file and rename to HASH.css/HASH.js
    files.each { f ->
        def fn = f.toString().replace('\\', '/') - base
        println "Found resource: $fn"
        def name = f.name
        def relativeName = f.toString() - baseFile.toString()
        def target = new File(resDir, relativeName)
        if (!target.exists()) {
            println "Copying resource $f to $target"        
            ant.copy(file:f, tofile:target, overwrite:false)
        } else {
            println "Skipping copy of $f as file exists"
        }
        
        // trigger processing event for other plugins and app
        def data = [originalFile:f, newFile:target]
        event('PrepareStaticResource', [data])
        fileMappings[fn] = (data.newFile.toString()-resDir.toString()).replace('\\', '/')
    }
    
    // Create manifest output
    def manifest = new StringWriter()
    // Write mapping entry to manifest
    fileMappings.each { e ->
        manifest << "${e.key} ${e.value}\n"
    }
 
    println "Manifest:\n${manifest}"
}
*/